YELLOW ANDROID APK BUILD

This folder is prepared to build a test APK through GitHub Actions.

HOW TO BUILD:
1. Download and extract this ZIP.
2. Create/sign in to a GitHub account.
3. Create a NEW repository named yellow-social.
4. Upload all files and folders from this extracted folder to the repository root.
   IMPORTANT: include the hidden .github folder.
5. Open the repository's Actions tab.
6. Select "Build Yellow Android APK" and tap "Run workflow" (or push to main).
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, scroll to Artifacts, and download Yellow-debug-APK.
9. Extract the artifact ZIP; install app-debug.apk on your Android phone.
   Android may ask you to allow installation from that browser/file manager.

IMPORTANT LIMITATIONS:
- This produces a DEBUG/test APK, not a Play Store release.
- This app is still a frontend prototype. OTP is simulated locally and does not send real email/SMS.
- Chat, stories, friend discovery, notifications and AI are demo-only and do not sync between users.
- Do not enter real passwords or sensitive information.
- A production app needs secure backend services, real OTP delivery, database, realtime messaging,
  moderation/privacy features and a properly signed release build.
