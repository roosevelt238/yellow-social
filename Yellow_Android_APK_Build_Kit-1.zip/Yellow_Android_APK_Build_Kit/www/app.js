const $=id=>document.getElementById(id);
const screens=['welcome','auth','verify','profileSetup','home','chat','aiPanel','notifications','profile'];
function show(id){screens.forEach(s=>$(s).classList.toggle('hidden',s!==id));window.scrollTo(0,0)}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
let demoOtp='', pendingContact='', profile={};
$('startBtn').onclick=()=>{ $('authTitle').textContent='Create your account';$('authSub').textContent='Start with your email or phone number.';show('auth') };
$('loginBtn').onclick=()=>{ $('authTitle').textContent='Welcome back';$('authSub').textContent='Enter your email or phone number to continue.';show('auth') };
document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>show(b.dataset.back));
$('authForm').onsubmit=e=>{e.preventDefault();const email=$('email').value.trim(),phone=$('phone').value.trim();if(!email&&!phone){toast('Enter an email or phone number');return}pendingContact=email||phone;demoOtp=String(Math.floor(100000+Math.random()*900000));$('demoCode').textContent='Your demo OTP is: '+demoOtp;show('verify')};
$('verifyBtn').onclick=()=>{if($('otp').value.trim()!==demoOtp){toast('That code is not correct');return}show('profileSetup')};
let avatarData='';
$('avatarFile').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{avatarData=r.result;$('avatarPreview').innerHTML=`<img src="${avatarData}" alt="Profile preview">`};r.readAsDataURL(f)};
$('finishSetup').onclick=()=>{const name=$('displayName').value.trim(),handle=$('yellowName').value.trim().replace(/^@/,'');if(!name||!handle){toast('Add your display name and Yellow username');return}profile={name,handle:'@'+handle,avatar:avatarData};localStorage.setItem('yellowProfile',JSON.stringify(profile));renderProfile();show('home');toast('Welcome to Yellow 💛')};
function renderProfile(){if(!profile.name){try{profile=JSON.parse(localStorage.getItem('yellowProfile')||'{}')}catch{}}$('profileDisplay').textContent=profile.name||'Your profile';$('profileHandle').textContent=profile.handle||'@yourname';$('profileAvatar').innerHTML=profile.avatar?`<img src="${profile.avatar}" alt="Profile">`:(profile.name||'☺').slice(0,1).toUpperCase()}
document.querySelectorAll('.chat-row').forEach(row=>row.onclick=()=>{ $('chatName').textContent=row.dataset.name;show('chat') });
$('messageForm').onsubmit=e=>{e.preventDefault();const v=$('messageInput').value.trim();if(!v)return;const b=document.createElement('div');b.className='bubble mine';b.textContent=v;const small=document.createElement('small');small.textContent='now ✓';b.append(small);$('chatBody').append(b);$('messageInput').value='';$('chatBody').scrollTop=$('chatBody').scrollHeight};
$('aiBtn').onclick=()=>show('aiPanel');$('notifBtn').onclick=()=>show('notifications');$('profileTab').onclick=()=>{renderProfile();show('profile')};
$('messagesTab').onclick=()=>show('home');$('friendsTab').onclick=()=>toast('Friend discovery is coming next 💛');
$('newChat').onclick=()=>toast('Friend search will be connected in the next build');$('addStory').onclick=$('storyAdd').onclick=()=>toast('Text and mood stories are coming next');
$('aiForm').onsubmit=e=>{e.preventDefault();const q=$('aiInput').value.trim();if(!q)return;$('aiReply').textContent='Yellow AI: Keep it genuine 💛 Try saying something warm, simple and true to you. (Sample reply — connect an AI service for live answers.)';$('aiInput').value=''};
document.querySelectorAll('.suggestions button').forEach(b=>b.onclick=()=>{$('aiInput').value=b.textContent;$('aiForm').requestSubmit()});
$('logoutBtn').onclick=()=>{show('welcome');toast('You have logged out')};
$('searchInput').oninput=e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('.chat-row').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q)?'flex':'none')};
renderProfile();
